﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentRespawn : MonoBehaviour {
	public int Agent1InHP = 10;
	public int Agent2InHP = 10;
	public int Agent1dmg = 2;
	public int Agent2dmg = 2;

	public int CastleL = 10;
	public int CastleR = 10;
 
	public float spawnCD = 3;
	public float timeUntilSpawn = 3;
	public GameObject Agent1;
	public GameObject Agent2;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		timeUntilSpawn -= Time.deltaTime;
		if (timeUntilSpawn <= 0) {
			GameObject Agent1Clone = Instantiate(Agent1, new Vector3 (-38.0f, -13.89f, 0f), Quaternion.identity);
			Agent1Controller AI1 = Agent1Clone.gameObject.GetComponent<Agent1Controller> ();
			AI1.hp = Agent1InHP;
			AI1.dmg = Agent1dmg;

			GameObject Agent2Clone = Instantiate(Agent2, new Vector3 (38.0f, -13.89f, 0f), Quaternion.identity);
			Agent2Controller AI2 = Agent2Clone.gameObject.GetComponent<Agent2Controller> ();
			AI2.hp = Agent2InHP;
			AI2.dmg = Agent2dmg;
			timeUntilSpawn = spawnCD;
		}
	}
}
